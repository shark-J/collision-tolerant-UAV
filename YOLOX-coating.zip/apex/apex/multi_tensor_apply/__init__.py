from .multi_tensor_apply import MultiTensorApply

multi_tensor_applier = MultiTensorApply(2048*32)

